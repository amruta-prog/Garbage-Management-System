For Project run the path in browser

localhost/projects/garbage/web/index.html

1. Place the coding in below path 
c:\xampp\htdocs\projects\garbage\web

2. Opent  localhost/phpmyadmin
   Crete DB - garbage
   
3. Import garbage.sql 


localhost/projects/garbage/web/

Login Details
For Admin 
admin@gmail.com
test

Driver
driver@gmail.com
test

User
user@gmail.com
test